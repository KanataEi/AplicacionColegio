package Controlador;

import Modelo.Alumno;

import java.util.ArrayList;
import java.util.List;

public class ControladorAlumno {
    private List<Alumno> listaAlumnos = new ArrayList<>();

    public void registrarAlumno(String nombres, String apellidos, String grado, String seccion) {
        Alumno alumno = new Alumno(nombres, apellidos, grado, seccion);
        listaAlumnos.add(alumno);
    }

    public List<Alumno> obtenerListaAlumnos() {
        return listaAlumnos;
    }
}
