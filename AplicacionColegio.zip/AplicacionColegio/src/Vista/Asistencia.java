
package Vista;


public class Asistencia extends javax.swing.JFrame {

    public Asistencia() {
        initComponents();
        this.setLocationRelativeTo(null);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jbMatricula = new javax.swing.JButton();
        jbNotas = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jtAlumno = new javax.swing.JTextField();
        jcCurso = new javax.swing.JComboBox<>();
        jtAsistencia = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jtGradoAsi = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jtSeccionAsi = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jbInicio = new javax.swing.JButton();
        jbRegistrarAsistencia = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jbMatricula.setText("Matricula");
        jbMatricula.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbMatriculaActionPerformed(evt);
            }
        });

        jbNotas.setText("Notas");
        jbNotas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbNotasActionPerformed(evt);
            }
        });

        jLabel1.setText("Alumno");

        jLabel3.setText("Curso");

        jLabel4.setText("Asistencia");

        jtAlumno.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jtAlumnoActionPerformed(evt);
            }
        });

        jcCurso.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccione", "Ciencia", "Matematicas", "Arte", "Educacion Fisica", "Religion ", "Comunicacion", "Ingles" }));
        jcCurso.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jcCursoActionPerformed(evt);
            }
        });

        jtAsistencia.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jtAsistenciaActionPerformed(evt);
            }
        });

        jLabel5.setText("Grado");

        jtGradoAsi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jtGradoAsiActionPerformed(evt);
            }
        });

        jLabel6.setText("Seccion");

        jtSeccionAsi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jtSeccionAsiActionPerformed(evt);
            }
        });

        jLabel7.setText("Asistencia");

        jbInicio.setText("Inicio");
        jbInicio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbInicioActionPerformed(evt);
            }
        });

        jbRegistrarAsistencia.setText("Registrar Asistencia");
        jbRegistrarAsistencia.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbRegistrarAsistenciaActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(88, 88, 88)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel5)
                    .addComponent(jLabel1)
                    .addComponent(jLabel6)
                    .addComponent(jLabel3)
                    .addComponent(jLabel4))
                .addGap(16, 16, 16)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(27, 27, 27)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jbMatricula)
                            .addComponent(jtAsistencia)
                            .addComponent(jtSeccionAsi)
                            .addComponent(jtGradoAsi)
                            .addComponent(jtAlumno)
                            .addComponent(jcCurso, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jbRegistrarAsistencia, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))))
                .addGap(17, 17, 17)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jbNotas)
                        .addGap(39, 39, 39)
                        .addComponent(jbInicio))
                    .addComponent(jLabel7))
                .addContainerGap(158, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel7)
                .addGap(34, 34, 34)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jbMatricula)
                    .addComponent(jbNotas)
                    .addComponent(jbInicio))
                .addGap(55, 55, 55)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addComponent(jtAlumno, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(jtGradoAsi, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(23, 23, 23)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(jtSeccionAsi, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(41, 41, 41)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jcCurso, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3))
                .addGap(33, 33, 33)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(jtAsistencia, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(32, 32, 32)
                .addComponent(jbRegistrarAsistencia)
                .addContainerGap(58, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jcCursoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jcCursoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jcCursoActionPerformed

    private void jtAsistenciaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtAsistenciaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jtAsistenciaActionPerformed

    private void jtAlumnoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtAlumnoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jtAlumnoActionPerformed

    private void jtGradoAsiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtGradoAsiActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jtGradoAsiActionPerformed

    private void jbInicioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbInicioActionPerformed
        VistaInicio a = new VistaInicio();
        a.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_jbInicioActionPerformed

    private void jbMatriculaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbMatriculaActionPerformed
        Matricula b = new Matricula();
        b.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_jbMatriculaActionPerformed

    private void jbNotasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbNotasActionPerformed
        Notas c = new Notas ();
        c.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_jbNotasActionPerformed

    private void jtSeccionAsiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtSeccionAsiActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jtSeccionAsiActionPerformed

    private void jbRegistrarAsistenciaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbRegistrarAsistenciaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jbRegistrarAsistenciaActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Asistencia().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JButton jbInicio;
    private javax.swing.JButton jbMatricula;
    private javax.swing.JButton jbNotas;
    private javax.swing.JButton jbRegistrarAsistencia;
    private javax.swing.JComboBox<String> jcCurso;
    private javax.swing.JTextField jtAlumno;
    private javax.swing.JTextField jtAsistencia;
    private javax.swing.JTextField jtGradoAsi;
    private javax.swing.JTextField jtSeccionAsi;
    // End of variables declaration//GEN-END:variables
}
