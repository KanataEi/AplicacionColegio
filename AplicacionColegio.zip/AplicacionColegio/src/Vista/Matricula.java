
package Vista;
import Controlador.ControladorAlumno;
import Modelo.Alumno;
import javax.swing.table.DefaultTableModel;
public class Matricula extends javax.swing.JFrame {
    private DefaultTableModel modeloTabla;
    
    private void validarCampos() {
    String nombres = jtNombres.getText().trim();
    String apellidos = jtApellidos.getText().trim();
    String grado = jtGrado.getText().trim();
    String seccion = jtSeccion.getText().trim();

    boolean camposLlenos = !nombres.isEmpty() && !apellidos.isEmpty() && !grado.isEmpty() && !seccion.isEmpty();
    jbRegistrar.setEnabled(camposLlenos);
}

private void jtNombresKeyReleased(java.awt.event.KeyEvent evt) {
    validarCampos();
}

private void jtApellidosKeyReleased(java.awt.event.KeyEvent evt) {
    validarCampos();
}

private void jtGradoKeyReleased(java.awt.event.KeyEvent evt) {
    validarCampos();
}

private void jtSeccionKeyReleased(java.awt.event.KeyEvent evt) {
    validarCampos();
}
 
    private ControladorAlumno controlador;

    public Matricula() {
        initComponents();
        this.setLocationRelativeTo(null);
        
        controlador = new Controlador.ControladorAlumno();
        
    modeloTabla = new DefaultTableModel();
    modeloTabla.addColumn("Nombres");
    modeloTabla.addColumn("Apellidos");
    modeloTabla.addColumn("Grado");
    modeloTabla.addColumn("Seccion");
    
    jTableAlumnos.setModel(modeloTabla);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jbAsistencia = new javax.swing.JButton();
        jbNotas = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jtNombres = new javax.swing.JTextField();
        jtApellidos = new javax.swing.JTextField();
        jtGrado = new javax.swing.JTextField();
        jtSeccion = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jbInicio = new javax.swing.JButton();
        jbRegistrar = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTableAlumnos = new javax.swing.JTable();
        jbEliminar = new javax.swing.JButton();

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jbAsistencia.setText("Asistencia");
        jbAsistencia.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbAsistenciaActionPerformed(evt);
            }
        });

        jbNotas.setText("Notas");
        jbNotas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbNotasActionPerformed(evt);
            }
        });

        jLabel1.setText("Nombres");

        jLabel2.setText("Apellidos");

        jLabel3.setText("Grado");

        jLabel4.setText("Seccion");

        jtNombres.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jtNombresActionPerformed(evt);
            }
        });

        jtApellidos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jtApellidosActionPerformed(evt);
            }
        });

        jtGrado.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jtGradoActionPerformed(evt);
            }
        });

        jtSeccion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jtSeccionActionPerformed(evt);
            }
        });

        jLabel5.setText("Matricula");

        jbInicio.setText("Inicio");
        jbInicio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbInicioActionPerformed(evt);
            }
        });

        jbRegistrar.setText("Registrar");
        jbRegistrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbRegistrarActionPerformed(evt);
            }
        });

        jTableAlumnos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Nombres", "Apellidos", "Grado", "Seccion"
            }
        ));
        jScrollPane2.setViewportView(jTableAlumnos);

        jbEliminar.setText("Eliminar \n");
        jbEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbEliminarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(105, 105, 105)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel2)
                                    .addComponent(jLabel1)
                                    .addComponent(jLabel3)))
                            .addComponent(jLabel4, javax.swing.GroupLayout.Alignment.TRAILING))
                        .addGap(26, 26, 26)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jtNombres, javax.swing.GroupLayout.DEFAULT_SIZE, 243, Short.MAX_VALUE)
                            .addComponent(jtApellidos)
                            .addComponent(jtGrado, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jtSeccion, javax.swing.GroupLayout.Alignment.LEADING)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(69, 69, 69)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(165, 165, 165)
                        .addComponent(jbRegistrar)
                        .addGap(71, 71, 71)
                        .addComponent(jbEliminar))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(156, 156, 156)
                        .addComponent(jbAsistencia)
                        .addGap(34, 34, 34)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jbNotas)
                                .addGap(42, 42, 42)
                                .addComponent(jbInicio))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(jLabel5)
                                .addGap(126, 126, 126)))))
                .addContainerGap(89, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel5)
                .addGap(27, 27, 27)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jbAsistencia)
                    .addComponent(jbNotas)
                    .addComponent(jbInicio))
                .addGap(32, 32, 32)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jtNombres, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(31, 31, 31)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jtApellidos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(34, 34, 34)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(jtGrado, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(38, 38, 38)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(jtSeccion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jbRegistrar)
                    .addComponent(jbEliminar))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 402, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(31, 31, 31))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jbAsistenciaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbAsistenciaActionPerformed
        Asistencia a = new Asistencia();
        a.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_jbAsistenciaActionPerformed

    private void jbNotasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbNotasActionPerformed
        Notas b = new Notas();
        b.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_jbNotasActionPerformed

    private void jbInicioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbInicioActionPerformed
        VistaInicio c = new VistaInicio();
        c.setVisible(true);
        this.setVisible(false);
        
    }//GEN-LAST:event_jbInicioActionPerformed

    private void jtNombresActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtNombresActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jtNombresActionPerformed

    private void jtApellidosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtApellidosActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jtApellidosActionPerformed

    private void jtGradoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtGradoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jtGradoActionPerformed

    private void jtSeccionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtSeccionActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jtSeccionActionPerformed

    private void jbRegistrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbRegistrarActionPerformed
        String nombres = jtNombres.getText();
        String apellidos = jtApellidos.getText();
        String grado = jtGrado.getText();
        String seccion = jtSeccion.getText();

        controlador.registrarAlumno(nombres, apellidos, grado, seccion);
        jtNombres.setText("");
        jtApellidos.setText("");
        jtGrado.setText("");
        jtSeccion.setText("");
        
        modeloTabla.addRow(new Object[]{nombres, apellidos, grado, seccion});
    }//GEN-LAST:event_jbRegistrarActionPerformed

    private void jbEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbEliminarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jbEliminarActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Matricula.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Matricula.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Matricula.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Matricula.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Matricula().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTableAlumnos;
    private javax.swing.JButton jbAsistencia;
    private javax.swing.JButton jbEliminar;
    private javax.swing.JButton jbInicio;
    private javax.swing.JButton jbNotas;
    private javax.swing.JButton jbRegistrar;
    private javax.swing.JTextField jtApellidos;
    private javax.swing.JTextField jtGrado;
    private javax.swing.JTextField jtNombres;
    private javax.swing.JTextField jtSeccion;
    // End of variables declaration//GEN-END:variables
}
