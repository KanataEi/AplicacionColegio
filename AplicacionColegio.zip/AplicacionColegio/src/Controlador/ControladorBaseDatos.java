import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class ControladorBaseDatos {

    private static final String URL = "jdbc:mysql://localhost:3306/tu_base_de_datos";
    private static final String USER = "tu_usuario";
    private static final String PASSWORD = "tu_contraseña";

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }

    public static boolean insertarEstudiante(String nombres, String apellidos, String grado, String seccion) {
        try {
            Connection connection = getConnection();
            String query = "INSERT INTO estudiantes (nombres, apellidos, grado, seccion) VALUES (?, ?, ?, ?)";
            PreparedStatement pstmt = connection.prepareStatement(query);
            pstmt.setString(1, nombres);
            pstmt.setString(2, apellidos);
            pstmt.setString(3, grado);
            pstmt.setString(4, seccion);

            int resultado = pstmt.executeUpdate();
            pstmt.close();
            connection.close();

            return resultado > 0;
        } catch (SQLException ex) {
            System.out.println("Error al conectar con la base de datos: " + ex.getMessage());
            return false;
        }
    }
}