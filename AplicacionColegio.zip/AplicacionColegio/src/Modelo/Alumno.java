package Modelo;

public class Alumno {
    private String nombres;
    private String apellidos;
    private String grado;
    private String seccion;

    public Alumno(String nombres, String apellidos, String grado, String seccion) {
        this.nombres = nombres;
        this.apellidos = apellidos;
        this.grado = grado;
        this.seccion = seccion;
    }

    public String getNombres() {
        return nombres;
    }

    public String getApellidos() {
        return apellidos;
    }

    public String getGrado() {
        return grado;
    }

    public String getSeccion() {
        return seccion;
    }
}
